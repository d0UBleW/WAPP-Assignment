﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WAPP_Assignment
{
    public static class SessionManager
    {
    }
}